# Step 1： Configure iplist files<br>
example:
```
cat iplist
host1
host2
host3
host4
host5
host6
```
# Step2:  Issusing script autoexssh.sh
```
sh autoexssh.sh usernanme password
#example:
sh autoexssh root rootpassword
```
---
<h1>Note:</h1>

```
# The expect package needs be installed when you execute the autoexssh.sh scripts for every machine
# yum install -y expect
```
